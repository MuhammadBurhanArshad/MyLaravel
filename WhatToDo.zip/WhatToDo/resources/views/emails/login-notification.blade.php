@component('mail::message')
# New Login Detected

A new login was detected on your account:

- **IP Address:** {{ $deviceInfo['ip'] }}
- **Browser:** {{ $deviceInfo['browser'] }}
- **Time:** {{ $deviceInfo['time'] }}
- **Location:** {{ $deviceInfo['location'] }}

If this was you, you can ignore this message. If you don't recognize this activity, please secure your account immediately.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
