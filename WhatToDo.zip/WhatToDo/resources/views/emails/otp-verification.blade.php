@component('mail::message')
@if($purpose === 'registration')
# Verify Your Email Address
Your verification code is:
@else
# Two-Factor Authentication Required
Your login verification code is:
@endif

@component('mail::panel')
{{ $otp }}
@endcomponent

This code will expire in 15 minutes.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
