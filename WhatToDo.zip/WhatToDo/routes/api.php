<?php

use App\Http\Controllers\API\Admin\AdminController;
use App\Http\Controllers\API\User\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::prefix('/auth')->group(function() {
    Route::prefix('/user')->group(function() {
        Route::post('login', [UserController::class, 'login']);
        Route::post('register', [UserController::class, 'register']);
         Route::post('verify-otp', [UserController::class, 'verifyOtp']);
    });

    Route::prefix('/admin')->group(function() {
        Route::post('login', [AdminController::class, 'login']);
        Route::post('register', [AdminController::class, 'register']);
    });
});

Route::middleware(['auth:sanctum', 'user', 'verified'])->group(function () {
    Route::get('/profile', function (Request $request) {
         return $request->user();
    });

      Route::post('/enable-2fa', [UserController::class, 'enableTwoFactor']);
        Route::post('/disable-2fa', [UserController::class, 'disableTwoFactor']);
});


Route::middleware(['auth:sanctum', 'admin'])->prefix('/admin')->group(function () {
    Route::get('/profile', function (Request $request) {
        return $request->user();
    });
});
