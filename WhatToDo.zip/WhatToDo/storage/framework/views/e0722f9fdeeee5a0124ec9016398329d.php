<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\MyLaravel\WhatToDo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/panel.blade.php ENDPATH**/ ?>