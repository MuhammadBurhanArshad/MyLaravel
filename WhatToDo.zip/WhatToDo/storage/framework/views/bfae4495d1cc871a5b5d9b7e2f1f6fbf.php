<?php $__env->startComponent('mail::message'); ?>
# New Login Detected

A new login was detected on your account:

- **IP Address:** <?php echo new \Illuminate\Support\EncodedHtmlString($deviceInfo['ip']); ?>

- **Browser:** <?php echo new \Illuminate\Support\EncodedHtmlString($deviceInfo['browser']); ?>

- **Time:** <?php echo new \Illuminate\Support\EncodedHtmlString($deviceInfo['time']); ?>

- **Location:** <?php echo new \Illuminate\Support\EncodedHtmlString($deviceInfo['location']); ?>


If this was you, you can ignore this message. If you don't recognize this activity, please secure your account immediately.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\xampp\htdocs\MyLaravel\WhatToDo\resources\views/emails/login-notification.blade.php ENDPATH**/ ?>