<?php $__env->startComponent('mail::message'); ?>
<?php if($purpose === 'registration'): ?>
# Verify Your Email Address
Your verification code is:
<?php else: ?>
# Two-Factor Authentication Required
Your login verification code is:
<?php endif; ?>

<?php $__env->startComponent('mail::panel'); ?>
<?php echo new \Illuminate\Support\EncodedHtmlString($otp); ?>

<?php echo $__env->renderComponent(); ?>

This code will expire in 15 minutes.

Thanks,<br>
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\xampp\htdocs\MyLaravel\WhatToDo\resources\views/emails/otp-verification.blade.php ENDPATH**/ ?>