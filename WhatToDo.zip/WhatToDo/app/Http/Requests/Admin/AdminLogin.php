<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class AdminLogin extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'exists:admins,email'],
            'password' => ['required', 'string', Password::min(10)],
            'otp' => ['sometimes', 'numeric']
        ];
    }

    public function messages(): array
    {
        return [
            'email.exists' => 'No admin account found with this email',
            'password.min' => 'Admin passwords require at least 10 characters'
        ];
    }

    /**
     * Add IP validation for admin logins
     */
    protected function prepareForValidation()
    {
        $this->merge([
            'ip_address' => $this->ip() // Track login source
        ]);
    }
}
