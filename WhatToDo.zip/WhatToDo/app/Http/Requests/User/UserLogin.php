<?php

namespace App\Http\Requests\User;

use App\Http\Requests\BaseApiRequest;
use Illuminate\Validation\Rules\Password;

class UserLogin extends BaseApiRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'exists:users,email'],
            'password' => ['required', 'string', Password::min(8)],
            'remember_me' => ['sometimes', 'boolean']
        ];
    }

    public function messages(): array
    {
        return [
            'email.exists' => 'Invalid Credentials',
            'password.min' => 'Password must be at least 8 characters'
        ];
    }
}
