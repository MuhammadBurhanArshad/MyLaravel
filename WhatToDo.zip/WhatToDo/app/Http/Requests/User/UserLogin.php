<?php

namespace App\Http\Requests\User;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Password;

class UserLogin extends FormRequest
{
    public function authorize(): bool
    {
        return true; // Allow all login attempts (validation will handle auth)
    }

    public function rules(): array
    {
        return [
            'email' => ['required_without:phone', 'email', 'exists:users,email'],
            'phone' => ['required_without:email', 'string', 'exists:users,phone'],
            'password' => ['required', 'string', Password::min(8)],
            'remember_me' => ['sometimes', 'boolean']
        ];
    }

    public function messages(): array
    {
        return [
            'email.exists' => 'No account found with this email',
            'phone.exists' => 'No account found with this phone number',
            'password.min' => 'Password must be at least 8 characters'
        ];
    }

    /**
     * Prepare credentials for authentication attempt
     */
    public function getCredentials()
    {
        return $this->only(['email', 'phone', 'password']);
    }
}
