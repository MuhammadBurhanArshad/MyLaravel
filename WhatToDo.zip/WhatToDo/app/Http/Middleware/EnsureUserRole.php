<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserRole
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!$request->user() || !$request->user()->currentAccessToken()) {
            abort(401, 'Unauthenticated');
        }

        if (!$request->user() instanceof \App\Models\User) {
            abort(403, 'Unauthorized: Not a User');
        }

        return $next($request);
    }
}
