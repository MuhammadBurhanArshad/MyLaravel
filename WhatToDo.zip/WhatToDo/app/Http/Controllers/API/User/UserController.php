<?php

namespace App\Http\Controllers\API\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\User\UserLogin;
use App\Http\Requests\User\UserRegister;
use App\Http\Requests\VerifyOtpRequest;
use App\Models\User;
use App\Models\Otp;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\LoginNotification;
use App\Mail\OtpVerification;
use App\Services\UserService;
use App\Traits\APIResponse;
use Carbon\Carbon;
use Exception;

class UserController extends Controller
{
    use APIResponse;

    public function __construct(public UserService $userService)
    {

    }

    public function register(UserRegister $request)
    {
        try {
            $user = $this->userService->register($request);

            return $this->successResponse($user['name'] . " welcome! Please verify your email with the OTP sent.", [], 201);
        } catch (Exception $e) {
            return $this->errorResponse("Something went wrong", [], 500);
        }
    }

    public function login(UserLogin $request)
    {
        try {
            $response = $this->userService->login($request);

            return $this->successResponse(
                $response['message'],
                $response['data'],
                200
            );
        } catch (Exception $e) {
            return $this->errorResponse("Something went wrong", [], 500);
        }
    }

    public function verifyOtp(VerifyOtpRequest $request)
    {
         try {
            $response = $this->userService->verifyOTP($request);


            dd($response);

            // return $this->successResponse(
            //     $response['message'],
            //     $response['data'],
            //     200
            // );
        } catch (Exception $e) {
            return $this->errorResponse("Something went wrong", [], 500);
        }
        // $otp = OTP::where('email', $request->email)
        //         ->where('code', $request->code)
        //         ->where('purpose', $request->purpose)
        //         ->where('expires_at', '<', Carbon::now())
        //         ->first();

        // if (!$otp) {
        //     usleep(rand(200000, 500000));
        //     return response()->json(['message' => 'Invalid or expired OTP'], 401);
        // }

        //   $user = User::where('email', $validated['email'])->firstOrFail();

        // $user = $otp->user;
        // $user->update([
        //     'verified' => true,
        //     'email_verified_at' => now() // Also mark email as verified
        // ]);

        // $user = $otp->user;

        // if ($request->purpose === 'registration') {
        //     // Mark email as verified
        //     $user->email_verified_at = now();
        //     $user->save();

        //     return response()->json(['message' => 'Email verified successfully']);
        // }

        // if ($request->purpose === '2fa_login') {
        //     // Send login notification with device info
        //     $this->sendLoginNotification($user, $request);

        //     $token = $user->createToken('user_api_token')->plainTextToken;
        //     return response()->json(['token' => $token]);
        // }

        // $otp->delete();
    }

    public function resendOtp(Request $request)
    {
        $user = $request->user();

        if ($user->verified) {
            return response()->json(['message' => 'User already verified']);
        }

        $otp = $this->OTPService->generateOTP($user, 'verification', $request->ip(), $request->userAgent());

        Mail::to($user->email)->send(new OtpVerification($otp->code, 'verification'));

        return response()->json([
            'message' => 'New OTP sent',
            'otp_id' => $otp->id
        ]);
    }

    // protected function generateOtp(User $user, string $purpose, string $ipAddress = null, string $userAgent = null): Otp
    // {
    //     // Delete any existing OTPs for this user/purpose
    //     Otp::where('user_id', $user->id)
    //         ->where('purpose', $purpose)
    //         ->delete();

    //     return Otp::create([
    //         'user_id' => $user->id,
    //         'code' => Str::random(6), // or mt_rand(100000, 999999) for numeric OTP
    //         'purpose' => $purpose,
    //         'ip_address' => $ipAddress,
    //         'user_agent' => $userAgent,
    //         'expires_at' => Carbon::now()->addMinutes(15)
    //     ]);
    // }

    protected function sendLoginNotification(User $user, Request $request)
    {
        $deviceInfo = [
            'ip' => $request->ip(),
            'browser' => $request->userAgent(),
            'time' => now()->toDateTimeString(),
            'location' => $this->getLocationFromIp($request->ip())
        ];

        Mail::to($user->email)->send(new LoginNotification($deviceInfo));
    }

    protected function getLocationFromIp(string $ip)
    {
        // In a real application, you might use a service like ipinfo.io or MaxMind
        // This is a simplified version
        if ($ip === '127.0.0.1') {
            return 'Localhost';
        }

        // For production, consider using a proper IP geolocation service
        return 'Unknown location';
    }

    public function enableTwoFactor(Request $request)
    {
        $user = $request->user();

        if ($user->hasEnabledTwoFactor()) {
            return response()->json(['message' => 'Two-factor authentication is already enabled']);
        }

        $user->update([
            'two_factor_enabled' => true,
            'two_factor_method' => 'email' // default to email, could be configurable
        ]);

        return response()->json(['message' => 'Two-factor authentication has been enabled']);
    }

    public function disableTwoFactor(Request $request)
    {
        $request->user()->update([
            'two_factor_enabled' => false,
        ]);

        return response()->json(['message' => 'Two-factor authentication has been disabled']);
    }

}
