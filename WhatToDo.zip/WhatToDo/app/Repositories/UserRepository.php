<?php

namespace App\Repositories;

use App\Interfaces\UserInterface;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Hash;

class UserRepository implements UserInterface
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }
public function createUser(array $data): User
{
    return User::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'phone' => $data['phone'] ?? null,
        'image' => $data['image'] ?? null,
        'timezone' => $data['timezone'] ?? 'UTC',
        'date_of_birth' => isset($data['date_of_birth'])
            ? Carbon::parse($data['date_of_birth'])
            : null,
        'country' => $data['country'] ?? null,
        'city' => $data['city'] ?? null,
        'password' => Hash::make($data['password']),
        'verified' => false,
    ]);
}
}
