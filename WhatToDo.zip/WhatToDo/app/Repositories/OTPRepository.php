<?php

namespace App\Repositories;

use App\Interfaces\OTPInterface;
use App\Models\OTP;
use Carbon\Carbon;
use Illuminate\Support\Str;

class OTPRepository implements OTPInterface
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function generateOTP(
        object $user,
        string $purpose,
        ?string $ipAddress = null,
        ?string $userAgent = null
    ): OTP {

        //         $recentAttempts = OTP::where('ip_address', $ipAddress)
        //     ->where('created_at', '>', now()->subHour())
        //     ->count();

        // if ($recentAttempts > 5) {
        //     throw new \Exception('Too many OTP requests');
        // }

        // do {
        //     $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        // } while (OTP::where('code', $code)->exists());

        OTP::where('email', $user->email)
            ->where('purpose', $purpose)
            ->delete();

        return OTP::create([
            'email' => $user->email,
            'code' => rand(100000, 999999),
            'purpose' => $purpose,
            'ip_address' => $ipAddress,
            'user_agent' => $userAgent,
            'expires_at' => now()->addMinutes(15)
        ]);
    }

    public function verifyOTP(object $data): OTP {
        $otp = OTP::where('email', $data->email)
                ->where('code', $data->code)
                ->where('purpose', $data->purpose)
                ->where('expires_at', '<', Carbon::now())
                ->first();

        if (!$otp) {
            usleep(rand(200000, 500000));
        }

        return $otp;
    }
}
