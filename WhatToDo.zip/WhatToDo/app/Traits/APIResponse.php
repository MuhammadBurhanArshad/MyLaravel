<?php

namespace App\Traits;

trait APIResponse
{
    protected function defaultResponse(): array
    {
        return [
            'success' => false,
            'isAllowed' => false,
            'message' => '',
        ];
    }

    protected function successResponse($message = '', $data = [], $statusCode = 200)
    {
        return response()->json(array_merge($this->defaultResponse(), [
            'success' => true,
            'isAllowed' => true,
            'message' => $message
        ], $data), $statusCode);
    }

    protected function errorResponse($message = 'Something went wrong', $data = [],  $statusCode = 400)
    {
        return response()->json(array_merge($this->defaultResponse(), [
            'message' => $message,
        ], $data), $statusCode);
    }
}
