<?php

namespace App\Formatters;

use App\Models\User;

class UserFormatter
{
    /**
     * Formats user data for API responses
     *
     * @param \App\Models\User $user
     * @param bool $includeSensitive = false  // For admin vs public responses
     * @return array
     */
    public static function format(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'phone' => $user->phone,
            'image' => $user->image,
            'timezone' => $user->timezone,
            'dateOfBirth' => $user->date_of_birth,
            'country' => $user->country,
            'city' => $user->city,
            'createdAt' => $user->created_at,
            'updatedAt' => $user->updated_at,
        ];
    }
}
