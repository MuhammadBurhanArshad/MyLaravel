<?php

namespace App\Interfaces;

use App\Models\OTP;

interface OTPInterface
{
    public function generateOTP(
        object $user,
        string $purpose,
        ?string $ipAddress = null,
        ?string $userAgent = null
    ): OTP;

    public function verifyOTP(object $data): OTP;
}
