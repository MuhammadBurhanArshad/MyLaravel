<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class LoginNotification extends Mailable
{
    use Queueable, SerializesModels;

    public $deviceInfo;

    public function __construct(array $deviceInfo)
    {
        $this->deviceInfo = $deviceInfo;
    }

    public function build()
    {
        return $this->subject('New Login Notification')
                    ->markdown('emails.login-notification');
    }
}
