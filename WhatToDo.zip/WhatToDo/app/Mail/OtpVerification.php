<?php

namespace App\Mail;

use Exception;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OtpVerification extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public string $otp, public string $purpose)
    {
    }

    public function build()
    {
        $subject = $this->purpose === 'registration'
            ? 'Verify Your Email Address'
            : 'Your Login Verification Code';


        return $this->subject($subject)
                    ->markdown('emails.otp-verification');
    }
}
