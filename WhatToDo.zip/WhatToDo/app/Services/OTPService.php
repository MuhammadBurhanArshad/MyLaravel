<?php

namespace App\Services;

use App\Interfaces\OTPInterface;
use App\Models\OTP;
use Exception;

class OTPService
{
    /**
     * Create a new class instance.
     */
    public function __construct(public OTPInterface $OTPInterface)
    {
        //
    }

    public function generateOTP(
        object $user,
        string $purpose,
        ?string $ipAddress = null,
        ?string $userAgent = null
    ): OTP {
        return $this->OTPInterface->generateOTP(
            $user,
            $purpose,
            $ipAddress,
            $userAgent
        );
    }

    public function verifyOTP(object $data): OTP {
        return $this->OTPInterface->verifyOTP($data);
    }
}
