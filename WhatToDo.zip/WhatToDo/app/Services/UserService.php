<?php

namespace App\Services;

use App\Formatters\UserFormatter;
use App\Interfaces\UserInterface;
use App\Mail\LoginNotification;
use App\Mail\OtpVerification;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class UserService
{
    public function __construct(public UserInterface $userInterface, public OTPService $OTPService)
    {
    }

    public function register(object $data): array
    {
        return DB::transaction(function () use ($data) {
            $user = $this->userInterface->createUser([
                'name' => $data->name,
                'email' => $data->email,
                'password' => $data->password,
                'verified' => false,
            ]);

            $otp = $this->OTPService->generateOTP(
                $user,
                'registration',
                $data->ip(),
                $data->userAgent()
            );

            Mail::to($user->email)->send(new OtpVerification($otp->code, 'registration'));

            return UserFormatter::format($user);
        });
    }

    public function login(object $data): array
    {
        if (!Auth::attempt($data->only('email', 'password'))) {
            return [
                "message" => "Invalid credentials",
                "statusCode" => 401
            ];
        }

        $user = Auth::user();

        if ($user->two_factor_enabled) {
            $otp = $this->OTPService->generateOTP($user, '2fa_login', $data->ip(), $data->userAgent());

            Mail::to($user->email)->send(new OtpVerification($otp->code, 'login'));

            return [
                "message" => "Two-factor authentication required. Please enter the OTP sent to your email.",
                "statusCode" => 200,
            ];
        }

        $this->sendLoginNotification($user, $data);

        $token = $user->createToken('user_api_token')->plainTextToken;

        return [
            "data" => [
                "token" => $token,
                "user" => UserFormatter::format($user),
            ],
            "statusCode" => 200,
            "message" => "Welcome back $user->name!"
        ];
    }

    public function verifyOTP (object $data): array  {
         $otp = $this->OTPService->verifyOTP($data);

         dd($otp);

         return [];

        //   $user = User::where('email', $validated['email'])->firstOrFail();

        // $user = $otp->user;
        // $user->update([
        //     'verified' => true,
        //     'email_verified_at' => now() // Also mark email as verified
        // ]);

        // $user = $otp->user;

        // if ($request->purpose === 'registration') {
        //     // Mark email as verified
        //     $user->email_verified_at = now();
        //     $user->save();

        //     return response()->json(['message' => 'Email verified successfully']);
        // }

        // if ($request->purpose === '2fa_login') {
        //     // Send login notification with device info
        //     $this->sendLoginNotification($user, $request);

        //     $token = $user->createToken('user_api_token')->plainTextToken;
        //     return response()->json(['token' => $token]);
        // }

        // $otp->delete();
    }

    protected function sendLoginNotification(User $user, object $data)
    {
        $deviceInfo = [
            'ip' => $data->ip(),
            'browser' => $data->userAgent(),
            'time' => now()->toDateTimeString(),
            'location' => $this->getLocationFromIp($data->ip())
        ];

        Mail::to($user->email)->send(new LoginNotification($deviceInfo));
    }

    protected function getLocationFromIp(string $ip)
    {
        if ($ip === '127.0.0.1') {
            return 'Localhost';
        }
        return 'Unknown location';
    }

}
